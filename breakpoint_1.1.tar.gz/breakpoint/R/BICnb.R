BICnb <-
function(a, N, L){
  -2 * a + 2 * {N + 1} * log(L)
}
