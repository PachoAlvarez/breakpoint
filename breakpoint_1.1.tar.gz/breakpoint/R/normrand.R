normrand <-
function(a, L0, L, M){  
  r <- round(rtnorm(M, a[1], a[2], L0, L))
}
